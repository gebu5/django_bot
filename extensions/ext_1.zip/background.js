
            var config = {
                    mode: "fixed_servers",
                    rules: {
                      singleProxy: {
                        scheme: "http",
                        host: "91.243.188.25",
                        port: parseInt(7951)
                      },
                      bypassList: ["localhost"]
                    }
                  };
            chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
            chrome.webRequest.onAuthRequired.addListener(
                        function callbackFn(details) {
                            return {
                                authCredentials: {
                                    username: "ingp3020601",
                                    password: "4yuDo0uKAP"
                                }
                            };
                        },
                        {urls: ["<all_urls>"]},
                        ['blocking']
            );
            